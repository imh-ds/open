# Fresh confidence diagnostic development

2/60 datasets complete; 58 missing; 0 audit errors.
Small development probe; observed counts and gain summaries are diagnostics, not accepted reliability labels. D-040 failed outcome and thresholds remain unchanged.

Hypothetical fixed 1% false-alarm rate: historical per-setting assurance pass probability 67.7%; 20 independent equal-rate settings jointly about 0.0405%. Rates differ in practice; no posterior interpretation.

Independent gains and ideal population predictions are diagnostic only. Nonpositive raw values and all decision exclusions remain in case_metrics.csv.

           cell scenario  target_gap  assessed  eligible  above  cv_matched_median  independent_matched_median  ideal_gap_median  pattern_consistent
n300-p15-rho0.7 additive        0.00         1         1      0           0.000026                    0.000046          0.000000                   0
 n300-p5-rho0.7    mixed        0.04         1         1      0           0.019086                    0.029736          0.028963                   0

