# Interaction confidence study

Stage calibration: 2/2000 datasets; missing 1998; audit errors 0.
Fixed-pair Gaussian spline research only; thresholds are not a general p-value or a posterior probability.
Prediction decisions and descriptive supported-grid pattern flags are separate. Missing results remain unknown.
Complete-task and checkpoint costs overlap; interrupted costs can be unknown.

Threshold artifact ready: False. Confirmation cannot start until this artifact is audited, committed and separately frozen.

![Research study summary](SUMMARY.png)
