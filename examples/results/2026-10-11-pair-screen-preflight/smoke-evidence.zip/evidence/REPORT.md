# Pair-screen development results

Completed 4/960 planned tasks; audit errors 0.
Development only. No cutoff or interaction-retention rule is accepted.

Counts retain 20 planned independent datasets per cell. Rank bounds include unassessed pairs and missing tasks.
True detail / any displayed are operational display coverage, not population detection or absence.

|Scenario|N|p|Engine|Complete|True top one bounds|True detail bounds|Any displayed bounds|Mean test skill|
|---|---:|---:|---|---:|---|---|---|---:|
|noise|80|5|random_forest|0/20|NA|NA|[0, 20]|NA|
|noise|80|5|gbm|0/20|NA|NA|[0, 20]|NA|
|noise|300|5|random_forest|0/20|NA|NA|[0, 20]|NA|
|noise|300|5|gbm|0/20|NA|NA|[0, 20]|NA|
|noise|600|5|random_forest|0/20|NA|NA|[0, 20]|NA|
|noise|600|5|gbm|0/20|NA|NA|[0, 20]|NA|
|noise|300|15|random_forest|0/20|NA|NA|[0, 20]|NA|
|noise|300|15|gbm|0/20|NA|NA|[0, 20]|NA|
|additive|80|5|random_forest|0/20|NA|NA|[0, 20]|NA|
|additive|80|5|gbm|0/20|NA|NA|[0, 20]|NA|
|additive|300|5|random_forest|0/20|NA|NA|[0, 20]|NA|
|additive|300|5|gbm|0/20|NA|NA|[0, 20]|NA|
|additive|600|5|random_forest|0/20|NA|NA|[0, 20]|NA|
|additive|600|5|gbm|0/20|NA|NA|[0, 20]|NA|
|additive|300|15|random_forest|0/20|NA|NA|[0, 20]|NA|
|additive|300|15|gbm|0/20|NA|NA|[0, 20]|NA|
|pure|80|5|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|pure|80|5|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|pure|300|5|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|pure|300|5|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|pure|600|5|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|pure|600|5|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|pure|300|15|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|pure|300|15|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|mixed|80|5|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|mixed|80|5|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|mixed|300|5|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|mixed|300|5|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|mixed|600|5|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|mixed|600|5|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|mixed|300|15|random_forest|2/20|[2, 20]|[2, 20]|[2, 20]|0.518|
|mixed|300|15|gbm|2/20|[2, 20]|[2, 20]|[2, 20]|0.504|
|correlated_additive|80|5|random_forest|0/20|NA|NA|[0, 20]|NA|
|correlated_additive|80|5|gbm|0/20|NA|NA|[0, 20]|NA|
|correlated_additive|300|5|random_forest|0/20|NA|NA|[0, 20]|NA|
|correlated_additive|300|5|gbm|0/20|NA|NA|[0, 20]|NA|
|correlated_additive|600|5|random_forest|0/20|NA|NA|[0, 20]|NA|
|correlated_additive|600|5|gbm|0/20|NA|NA|[0, 20]|NA|
|correlated_additive|300|15|random_forest|0/20|NA|NA|[0, 20]|NA|
|correlated_additive|300|15|gbm|0/20|NA|NA|[0, 20]|NA|
|correlated_mixed|80|5|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|correlated_mixed|80|5|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|correlated_mixed|300|5|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|correlated_mixed|300|5|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|correlated_mixed|600|5|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|correlated_mixed|600|5|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|correlated_mixed|300|15|random_forest|0/20|[0, 20]|[0, 20]|[0, 20]|NA|
|correlated_mixed|300|15|gbm|0/20|[0, 20]|[0, 20]|[0, 20]|NA|

![Prespecified summary plots](SUMMARY.png)

See summary.csv for assessed-pair fractions and Wilson intervals; cutoff_sensitivity.csv
retains assessed/missing counts and unknown-inclusive exceedance bounds. No cutoff is selected.
