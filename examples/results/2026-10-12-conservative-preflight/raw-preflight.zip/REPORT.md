# Conservative joint-model selection development

Complete 2/240; missing 238; audit errors 0.
Production defaults unchanged. No threshold or model adopted. Five planned datasets per cell.
Oracle gap is a Gaussian population reference, not a bound on fitted gains.
Fixed pair comparisons do not establish network recovery or all-pair false-positive rates.

Top-level costs cover verified complete tasks. Audit JSON separately retains completed-checkpoint costs,
including partial tasks. These totals overlap: do not add them together. Interrupted work without a
completed checkpoint has unknown cost; saved costs are a lower bound on actual computation.

|Correlation|Signal|N|p|Complete / 5|Population gap|
|---:|---|---:|---:|---:|---:|
|0.0|noise|80|5|1|0.0000|
|0.0|noise|300|5|0|0.0000|
|0.0|noise|600|5|0|0.0000|
|0.0|noise|300|15|0|0.0000|
|0.0|additive|80|5|0|0.0000|
|0.0|additive|300|5|0|0.0000|
|0.0|additive|600|5|0|0.0000|
|0.0|additive|300|15|0|0.0000|
|0.0|pure|80|5|0|0.6000|
|0.0|pure|300|5|0|0.6000|
|0.0|pure|600|5|0|0.6000|
|0.0|pure|300|15|0|0.6000|
|0.0|mixed|80|5|0|0.1920|
|0.0|mixed|300|5|0|0.1920|
|0.0|mixed|600|5|0|0.1920|
|0.0|mixed|300|15|0|0.1920|
|0.7|noise|80|5|0|0.0000|
|0.7|noise|300|5|0|0.0000|
|0.7|noise|600|5|0|0.0000|
|0.7|noise|300|15|0|0.0000|
|0.7|additive|80|5|0|0.0000|
|0.7|additive|300|5|0|0.0000|
|0.7|additive|600|5|0|0.0000|
|0.7|additive|300|15|0|0.0000|
|0.7|pure|80|5|0|0.0703|
|0.7|pure|300|5|0|0.0703|
|0.7|pure|600|5|0|0.0703|
|0.7|pure|300|15|0|0.0703|
|0.7|mixed|80|5|0|0.0213|
|0.7|mixed|300|5|1|0.0213|
|0.7|mixed|600|5|0|0.0213|
|0.7|mixed|300|15|0|0.0213|
|0.9|noise|80|5|0|0.0000|
|0.9|noise|300|5|0|0.0000|
|0.9|noise|600|5|0|0.0000|
|0.9|noise|300|15|0|0.0000|
|0.9|additive|80|5|0|0.0000|
|0.9|additive|300|5|0|0.0000|
|0.9|additive|600|5|0|0.0000|
|0.9|additive|300|15|0|0.0000|
|0.9|pure|80|5|0|0.0066|
|0.9|pure|300|5|0|0.0066|
|0.9|pure|600|5|0|0.0066|
|0.9|pure|300|15|0|0.0066|
|0.9|mixed|80|5|0|0.0021|
|0.9|mixed|300|5|0|0.0021|
|0.9|mixed|600|5|0|0.0021|
|0.9|mixed|300|15|0|0.0021|

![Independent assessment](conservative-summary.png)
